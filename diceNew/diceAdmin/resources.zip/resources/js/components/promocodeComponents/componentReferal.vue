<template>
    <div class="generate_referal">
        <div class="data_element">
            <h5>Сумма</h5>
            <input type="text" placeholder="100">
        </div>
        <div class="data_element">
            <h5>Кол-во активаций</h5>
            <input type="text" placeholder="200">
        </div>
        <div class="data_element">
            <h5>Кол-во промиков</h5>
            <input type="text" placeholder="100">
        </div>
        <div class="data_element">
            <h5>Вагер</h5>
            <input type="text" placeholder="50">
        </div>
        <div class="data_element">
            <h5>Название промокода</h5>
            <input type="text" placeholder="WTF2023">
        </div>
        <div class="data_element">
            <h5>Рефер</h5>
            <input type="text" placeholder="banditos">
        </div>
        <div class="button_accept">
            <button>Применить</button>
        </div>
    </div>
</template>
<script>
export default {

}
</script>
